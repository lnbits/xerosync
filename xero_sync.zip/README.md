# Xero Sync Extension

## LNbits -> Xero wallet sync
